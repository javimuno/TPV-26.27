#pragma once
#include "SceneObject.h"
#include "GameObject.h"

class MobileObject : public SceneObject
{
private:
	Vector2D<float> speed;

	void move(float delta);

	virtual bool specificUpdate(float delta) = 0;

public:
	MobileObject(Texture* text, const Point2D<float>& pos, const Vector2D<float>& dim, const Vector2D<float>& vel, Game* g);

	virtual bool update(float dt) override;
};
